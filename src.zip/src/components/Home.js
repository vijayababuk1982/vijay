 
import React, { Component } from 'react';


class Home extends Component {
     
    render() {
        return ( 
        <div>
          <center><h1>Welcome to Demo </h1></center>
           
        </div>
      )
    };
}
    export default Home;
