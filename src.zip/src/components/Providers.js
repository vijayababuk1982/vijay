
import React, { Component } from 'react';
    
class Providers extends Component {
     
  state = {
     providers: [],
     
  }


  componentDidMount() {
    fetch('https://api.inquickerstaging.com/v3/winter.inquickerstaging.com/providers?include=locations%2Cschedules.location&page%5Bnumber%5D=1&page%5Bsize%5D=10')
          
    .then(res => res.json())
.then((data) => {
 //console.log(data);
 console.log("providers"+data.data);
 this.setState({ providers: data.data })
 } )
    .catch(console.log)

   // this.setState({ services: this.props.services })
  }


  renderProvidersTableHeader() {
        
    console.log("inside :" + JSON.stringify(this.state.providers));
  let header=Object.keys(this.state.providers[0]!=null?this.state.providers[0]:"")
  
   return header.map((key, index) => {
      return <th key={index}>{key.toUpperCase()}</th>
      
  })

 
}


renderProvidersTableData() {
      
  if(this.state.providers!=null)
  {
  
    return this.state.providers.map((service, index) => {
       const { id, type,links,attributes } = service //destructuring
       return (
          <tr key={index+1}>
              <td>
       {id}                   </td>
             <td>{type}</td>
             <td>{links.self}</td>
             <td>{attributes.subspecialties}</td>

          </tr>
       )
    })
  }
  else
  {
  return;
  }
 }




    render() {
        return (   <div>
          <center><h1>Providers List</h1></center>
          <table className='tblDemo'>
                  <tbody>
                  <tr>{this.renderProvidersTableHeader()}</tr>
                  {this.renderProvidersTableData()}
                
              </tbody>
              </table>
              :
               <div></div>
         
        </div>
      )

    };
}
    export default Providers
