import React, { Component } from 'react';
import {Link} from 'react-router-dom';

 

    class App extends Component {
      state = {
        services: [],
        providers: []
      }
 
      componentDidMount() {
      /*  fetch('https://api.inquickerstaging.com/v3/winter.inquickerstaging.com/services')
        .then(res => res.json())
        .then((data) => {
          //console.log(data);
          console.log(data.data);
          this.setState({ services: data.data })
        })
        .catch(console.log)*/
/*
        fetch('https://api.inquickerstaging.com/v3/winter.inquickerstaging.com/providers?include=locations%2Cschedules.location&page%5Bnumber%5D=1&page%5Bsize%5D=10')
        .then(res => res.json())
        .then((data) => {
          //console.log(data);
          console.log(data.data);
          this.setState({ services: data.data })
        })
        .catch(console.log)
      }
*/
    }
      render() {
        return (
          /*<HashRouter>
          <Switch>
  <Route exact path='/' component={Home}/>
   <Route path='/Services' component={Services}/>
  <Route path='/Providers' component={Providers}/>
</Switch>
</HashRouter>*/
<div>
<center><h1>Welcome to Services Demo </h1></center>

<div>
                                 <Link to="Services">Services</Link>
                {this.props.children}
            </div>

            <div>
                
                <Link to="Providers">Providers</Link>
                {this.props.children}
            </div>
 
</div>

         // <Services services={this.state.services} />
          //<Providers provides={this.state.providers} />
          
          
        );
      }
    }

    export default App;