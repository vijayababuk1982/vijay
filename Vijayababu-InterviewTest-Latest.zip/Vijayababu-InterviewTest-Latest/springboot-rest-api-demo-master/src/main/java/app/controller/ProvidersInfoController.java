package app.controller;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import app.model.ProvidersInfo;
import app.repository.ProviderInfoCustomRepository;
import app.repository.ProvidersInfoRepository;

@RestController
@RequestMapping("/ProvidersInfo")
public class ProvidersInfoController {


	  @Autowired
	  private ProvidersInfoRepository providersInfoRepository;
	  
	  @RequestMapping(method = RequestMethod.GET)
	  public Map<String, Object> getAllProviders(){
	    List<ProvidersInfo> providers = providersInfoRepository.findAll();
	    Map<String, Object> response = new LinkedHashMap<String, Object>();
	    response.put("totalproviders", providers.size());
	    response.put("providers", providers);
	    return response;
	  }
	  
	  

	  @RequestMapping(method = RequestMethod.GET, value="/{id}")
	  public ProvidersInfo getProviderDetailsByName(@PathVariable("id") String id){
	    return providersInfoRepository.findOne(id);
	  }	  	  

	  @RequestMapping(method = RequestMethod.PUT, value="/{id}")
	  public Map<String, Object> editProviderInfo(@PathVariable("id") String id, 
	      @RequestBody Map<String, Object> prMap)
	  {
		  ProvidersInfo pr = new ProvidersInfo(prMap.get("pid").toString(), 
				  prMap.get("name").toString(),
				  prMap.get("baseUrl").toString(),
				  prMap.get("countryISOCode").toString());
		         pr.setid(id);
	    
	    
	    Map<String, Object> response = new LinkedHashMap<String, Object>();
	    response.put("message", "Provider is updated in DB");
	    response.put("providersInfo", providersInfoRepository.save(pr));
	    return response;
	  }
	  	  
	  @RequestMapping(method = RequestMethod.POST)
	  public Map<String, Object> createProvider(@RequestBody Map<String, Object> providerMap)
	  {
		  ProvidersInfo providersInfo = new ProvidersInfo(providerMap.get("pid").toString(), 
				  providerMap.get("name").toString(),
				  providerMap.get("baseUrl").toString(),
				  providerMap.get("countryISOCode").toString());
	    
	    Map<String, Object> response = new LinkedHashMap<String, Object>();
	    response.put("message", "Provider is added to DB");
	    response.put("providersInfo", providersInfoRepository.save(providersInfo));
	    return response;
	  }
	 
	  @RequestMapping(method = RequestMethod.GET, value="/countryISOCode/{countryISOCode}")
	  public Map<String, Object> getAllProvidersbyCountry(@PathVariable("countryISOCode") String countryISOCode)
{
	    List<ProvidersInfo> providers = providersInfoRepository.countryquery(countryISOCode);
	    Map<String, Object> response = new LinkedHashMap<String, Object>();
	    response.put("totalproviders", providers.size());
	    response.put("providers", providers);
	    return response;
	  }
	  
	  
	  @RequestMapping(method = RequestMethod.GET, value="/name/{name}")
	  public Map<String, Object> getAllProvidersbyName(@PathVariable("name") String name)
{
	    List<ProvidersInfo> providers = providersInfoRepository.namequery(name);
	    Map<String, Object> response = new LinkedHashMap<String, Object>();
	    response.put("totalproviders", providers.size());
	    response.put("providers", providers);
	    return response;
	  }


}
