package app.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.beans.factory.annotation.Autowired;

import app.model.ProvidersInfo;

public class ProviderInfoCustomRepositoryImpl implements ProviderInfoCustomRepository {

	@Autowired
	private final MongoTemplate mongoTemplate;
	
	
	public ProviderInfoCustomRepositoryImpl(MongoTemplate mongoTemplate) {
		this.mongoTemplate = mongoTemplate;
	}
	
	@Override
	public List<ProvidersInfo> countryquery(String countryISOCode) {
		final Query query = new Query();		
		query.addCriteria(Criteria.where("countryISOCode").is(countryISOCode));		
		return mongoTemplate.find(query, ProvidersInfo.class);
	}
	
	@Override
	public List<ProvidersInfo> namequery(String name) {
		final Query query = new Query();		
		query.addCriteria(Criteria.where("name").is(name));		
		return mongoTemplate.find(query, ProvidersInfo.class);
	}

}
