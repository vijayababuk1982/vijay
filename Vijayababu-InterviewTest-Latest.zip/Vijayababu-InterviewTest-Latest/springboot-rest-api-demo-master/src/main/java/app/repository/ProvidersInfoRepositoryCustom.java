package app.repository;

import java.util.List;

import app.model.ProvidersInfo;

public interface ProvidersInfoRepositoryCustom {
	List<ProvidersInfo> countryquery(String countryISOCode);
	List<ProvidersInfo> namequery(String name);
}
