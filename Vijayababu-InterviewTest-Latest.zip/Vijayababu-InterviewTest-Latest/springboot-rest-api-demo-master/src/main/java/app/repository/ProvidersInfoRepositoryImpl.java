package app.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import app.model.ProvidersInfo;

public class ProvidersInfoRepositoryImpl implements ProvidersInfoRepositoryCustom {
	
	@Autowired
    MongoTemplate mongoTemplate;
		
	@Override
	public List<ProvidersInfo> countryquery(String countryISOCode) {
		final Query query = new Query();		
		query.addCriteria(Criteria.where("countryISOCode").is(countryISOCode));		
		return mongoTemplate.find(query, ProvidersInfo.class);
	}
	
	@Override
	public List<ProvidersInfo> namequery(String name) {
		final Query query = new Query();		
		query.addCriteria(Criteria.where("name").is(name));		
		return mongoTemplate.find(query, ProvidersInfo.class);
	}


}
