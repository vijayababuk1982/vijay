package app.repository;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import app.model.ProvidersInfo;


public interface ProviderInfoCustomRepository  {
	
	List<ProvidersInfo> countryquery(String countryISOCode);
	List<ProvidersInfo> namequery(String name);

}
