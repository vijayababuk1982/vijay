package app.model;

import org.springframework.data.annotation.Id;

public class ProvidersInfo {	
	@Id
	public String id;	
	public String pid;
	public String name;
	public String baseUrl;
	public String countryISOCode;
	
	
	// Constructors
	public ProvidersInfo() {}

	public ProvidersInfo( String pid, String name, String baseUrl, String countryISOCode ) {
	 
	  this.pid = pid;
	  this.name = name;
	  this.baseUrl = baseUrl;
	  this.countryISOCode = countryISOCode;
	}

	
	public String getid() {
		return id;
	}

	public void setid(String id) {
		this.id = id;
	}

    public String getpid() {
        return pid;
    }
    public void setpid(String pid) {
        this.pid = pid;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    public String getbaseUrl() {
        return baseUrl;
    }
    public void setbaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }   

    public String getcountryISOCode() {
        return countryISOCode;
    }
    public void setcountryISOCode(String countryISOCode) {
        this.countryISOCode = countryISOCode;
    }

}
