package app.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import app.model.ProvidersInfoDAL;

import app.model.ProvidersInfo;

public class ProvidersInfoDALDetails implements ProvidersInfoDAL{
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Override
	public List<ProvidersInfo> getAllProviders()
	{
		return mongoTemplate.findAll(ProvidersInfo.class);
	}
	
	@Override
	public ProvidersInfo getProvidersInfoByName(String name)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("name").is(name));
		return mongoTemplate.findOne(query, ProvidersInfo.class);	
		
	}
	/*
	@Override
	public int getCountByCountry(String countryISOCode)
	{
	//	List<ProvidersInfo> lpi = new ArrayList<ProvidersInfo>();
		Query query = new Query();
		query.addCriteria(Criteria.where("countryISOCode").is(countryISOCode));
		return mongoTemplate.find(query, ProvidersInfo.class).size();
		
	}*/
	/*
	@Override
	public List<CountryInfo> getCountriesByCount()
	{	
			Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.group("countryISOCode"));
	return	(List<CountryInfo>) mongoTemplate.aggregate(aggregation, "countryISOCode", CountryInfo.class).getMappedResults();
		
	}	*/

	@Override
	public ProvidersInfo addNewProvider(ProvidersInfo pr) {
		mongoTemplate.save(pr);		
		return pr;
	}
	
	@Override
	public ProvidersInfo updateProvidersInfoByName(String name, String  countryISOCode)
	{
		Query query1 = new Query(Criteria.where("name").is(name));
        Update update1 = new Update();
        update1.set("countryISOCode", countryISOCode);                
         mongoTemplate.updateFirst(query1, update1, ProvidersInfo.class);
         //return getProvidersInfoByName(name);
         Query query = new Query();
 		query.addCriteria(Criteria.where("name").is(name));
 		return mongoTemplate.findOne(query, ProvidersInfo.class);	
	}

	@Override
	public List<ProvidersInfo> getProviderCountriesCount(String country) {
		// TODO Auto-generated method stub
		Query query = new Query();
		query.addCriteria(Criteria.where("countryISOCode").is(country));
		return (List<ProvidersInfo>) mongoTemplate.findOne(query, ProvidersInfo.class);
	}

	@Override
	public List<ProvidersInfo> getProviderByName(String name) {
		// TODO Auto-generated method stub
		Query query = new Query();
		query.addCriteria(Criteria.where("name").is(name));
		return (List<ProvidersInfo>) mongoTemplate.findOne(query, ProvidersInfo.class);
	}

}
