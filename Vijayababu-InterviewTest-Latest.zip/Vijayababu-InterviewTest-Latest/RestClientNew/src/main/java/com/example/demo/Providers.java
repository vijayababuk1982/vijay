package com.example.demo;
import java.util.List;
import java.util.ArrayList;
public class Providers
{   
      
    private List<Provider> provider = new ArrayList<Provider>();   
    
    public List<Provider> getProviderList() {
        return provider;
    }
 
    public void setProviderList(List<Provider> provider) {
        this.provider = provider;
    }
}

