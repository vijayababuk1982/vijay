package com.example.demo;
import java.util.ArrayList;
import java.util.List;


 
public class Provider {
	
	
	private String id;
	private String name;	
	private String baseUrl;
	private String countryISOCode;
	/*
	 private String PRIORITY;
	private String loginUrl;
	private String favicon;
	private String logo;
	private String status;
	private String authType;
	private String languageISOCode;
	private String primaryLanguageISOCode;
	
	private String lastModified;
	private String forgetPasswordUrl;
	private String isAutoRefreshEnabled;
	private String dataset;*/
	
	    
	    public String getid() {
	        return id;
	    }
	    public void setid(String id) {
	        this.id = id;
	    }
	    public String getName() {
	        return name;
	    }
	    public void setName(String name) {
	        this.name = name;
	    }
	    
	    public String getbaseUrl() {
	        return baseUrl;
	    }
	    public void setbaseUrl(String baseUrl) {
	        this.baseUrl = baseUrl;
	    }
	    

	    public String getcountryISOCode() {
	        return countryISOCode;
	    }
	    public void setcountryISOCode(String countryISOCode) {
	        this.countryISOCode = countryISOCode;
	    }
   
	    
/*
 
  public String getPRIORITY() {
	        return PRIORITY;
	    }
	    public void setPRIORITY(String PRIORITY) {
	        this.PRIORITY = PRIORITY;
	    }
	 
	    public String getloginUrl() {
	        return loginUrl;
	    }
	    public void setloginUrl(String loginUrl) {
	        this.loginUrl = loginUrl;
	    }
	    
	    	    public String getfavicon() {
	        return favicon;
	    }
	    public void setfavicon(String favicon) {
	        this.favicon = favicon;
	    }
	    

	    public String getlogo() {
	        return favicon;
	    }
	    public void setlogo(String logo) {
	        this.logo = logo;
	    }
	    
	    public String getstatus() {
	        return status;
	    }
	    public void setstatus(String status) {
	        this.status = status;
	    }
	    
	    
	    public String getauthType() {
	        return authType;
	    }
	    public void setauthType(String authType) {
	        this.authType = authType;
	    }
	    
	    
	    public String getlanguageISOCode() {
	        return languageISOCode;
	    }
	    public void setlanguageISOCode(String languageISOCode) {
	        this.languageISOCode = languageISOCode;
	    }
	    public String getprimaryLanguageISOCode() {
	        return primaryLanguageISOCode;
	    }
	    public void setprimaryLanguageISOCode(String primaryLanguageISOCode) {
	        this.primaryLanguageISOCode = primaryLanguageISOCode;
	    }
	    

	    public String getlastModified() {
	        return lastModified;
	    }
	    public void setlastModified(String lastModified) {
	        this.lastModified = lastModified;
	    }


	    public String getforgetPasswordUrl() {
	        return forgetPasswordUrl;
	    }
	    public void setforgetPasswordUrl(String forgetPasswordUrl) {
	        this.forgetPasswordUrl = forgetPasswordUrl;
	    }
	    

	    public String getisAutoRefreshEnabled() {
	        return isAutoRefreshEnabled;
	    }
	    public void setisAutoRefreshEnabled(String isAutoRefreshEnabled) {
	        this.isAutoRefreshEnabled = isAutoRefreshEnabled;
	    }
	    
	    public String getdataset() {
	        return dataset;
	    }
	    public void setdataset(String dataset) {
	        this.dataset = dataset;
	    }*/

}

