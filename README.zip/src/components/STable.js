import React, { Component } from 'react';
//import {Table } from 'react-bootstrap';
//import '../css/Table.css';
//import '../../node_modules/react-bootstrap-table/css/react-bootstrap-table.css';


class STable extends Component {
  render() {
    return (
      <div>
               </div>        
    );
  }
}
 
export default STable;