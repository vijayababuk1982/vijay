 
import React, { Component } from 'react';
import {Link} from 'react-router-dom';
//import STable from './components/STable';
//import STable from './STable';

class Services extends Component {
     
    constructor(props){
        super(props);
        this.handleClick = this.handleClick.bind(this);
      //this.GetProviders = this.GetProviders.bind(this);

        
     }
     
    state = {
        services: [],
        providers: [],
        matchProviders: [],        
        isServiceClicked: false,
        ServiceSelName:"",   
        ServiceSelected:"" ,
         isp: false,
   
      }
    


    
 
      componentDidMount() {
        fetch('https://api.inquickerstaging.com/v3/winter.inquickerstaging.com/services')
        .then(res => res.json())
        .then((data) => {
          //console.log(data);
          console.log(data.data);
          this.setState({ services: data.data })
        })
        .catch(console.log)

       // this.setState({ services: this.props.services })
      }

      handleClick(e) {
        //e.preventDefault();
     //   console.log('The link was clicked.');

        console.log('Selected id:'+JSON.stringify(e.target.id));
        console.log('Selected name:'+JSON.stringify(e.target.name));
       
     //GetProviders(e.target.id);    
        this.setState({ 
            isServiceClicked: true,
            isp: false,            
            ServiceSelected:e.target.id,
             ServiceSelName:e.target.name,   
                
         })

         fetch('https://api.inquickerstaging.com/v3/winter.inquickerstaging.com/providers?include=locations%2Cschedules.location&page%5Bnumber%5D=1&page%5Bsize%5D=10')
          
         .then(res => res.json())
    .then((data) => {
      //console.log(data);
      console.log("providers"+data.data);
      this.setState({ providers: data.data })
       
      let newpr=[];
 this.state.providers.forEach((pr, index) => {
let att = pr.attributes?pr.attributes:{};
let subs = att.subspecialties?att.subspecialties:[];
//console.log("att m"+index+":"+att);
subs.forEach(element => {
   
  console.log("att VALUE:"+index+ ":"+element + " ORG:" + this.state.ServiceSelName);
    //console.log("att"+index+":"+element);
    if(element===this.state.ServiceSelName)
    {
      newpr.push(pr);
      //console.log("PASS:"+ JSON.stringify(pr));
     // this.state.matchProviders.push(pr);

      this.setState({ matchProviders: newpr,isp: true  });
             
      console.log("PASS1:"+ JSON.stringify(this.state.matchProviders));
       //  this.setState({  });
           
      console.log("att:"+index+ ":"+element);
      return;
    }
      
    
  })
 
});


console.log("providers NEW PR:"+JSON.stringify(newpr));
//
//console.log("providers2"+pr4);

//let temppr1 = temppr.filter((x)=>x.attributes.subspecialties.contains(e.target.id));

//let temppr1 = temppr.filter((x)=>x.attributes.subspecialties.contains('a'));


//console.log("filtered providers"+JSON.stringify(temppr1));


      
    })
    .catch(console.log ("error in getting providers data"))

      };
     


      renderServicesTableHeader() {
        
        let header=Object.keys(this.state.services[0]!=null?this.state.services[0]:"")
        //console.log("headers"+header);
        //header.insert(5,'Index');
        return header.map((key, index) => {
            return <th key={index}>{key.toUpperCase()}</th>
            
        })
     }
     
     renderProvidersTableHeader() {
        
          console.log("inside :" + JSON.stringify(this.state.providers));
        let header=Object.keys(this.state.providers[0]!=null?this.state.providers[0]:"")
        
         return header.map((key, index) => {
            return <th key={index}>{key.toUpperCase()}</th>
            
        })
      
       
    }
            
      renderServicesTableData() {
        return this.state.services.map((service, index) => {
           const { id, type,links, attributes } = service //destructuring
           return (
              <tr key={index+1}>
                  <td>
           <Link to="Services">{id}</Link>
                  </td>
                 <td>{type}</td>
<td> 
{
<button id={id} name={attributes.name} onClick={(e) => this.handleClick(e)}>
{links.self}
</button>}
  </td>

                  
                 <td>{attributes.name}</td>
              </tr>
           )
        })
     }

     renderProvidersTableData() {
      
      if(this.state.providers!=null)
      {
      
        return this.state.providers.map((service, index) => {
           const { id, type,links,attributes } = service //destructuring
           return (
              <tr key={index+1}>
                  <td>
           {id}                   </td>
                 <td>{type}</td>
                 <td>{links.self}</td>
                 <td>{attributes.subspecialties}</td>
 
              </tr>
           )
        })
      }
      else
      {
      return;
      }
     }


    render() {
        return (
            <div> 
        <div>
          <center><h1>Services-Providers</h1></center>
          <h1 id='title'>Services</h1>
            <table className='tblDemo'>
                  
              <tbody>
              
              <tr>{this.renderServicesTableHeader()}</tr>
              {this.renderServicesTableData()}
               
          </tbody>
          </table>
        </div>

        {
            this.state.isServiceClicked?
        <div id="divresults"  >
        
<div>
    <h4>Results</h4>
    <div> Service Name: {this.state.ServiceSelected}</div>
    
    {this.state.isp?
    <table className='tblDemo'>
                  <tbody>
                  <tr>{this.renderProvidersTableHeader()}</tr>
                  {this.renderProvidersTableData()}
                
              </tbody>
              </table>
              :
               <div></div>
    }
    
</div>
</div>
:
<div>
</div>
    }
    </div>
       )
    };
}
    export default Services;
