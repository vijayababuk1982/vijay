package com.example.demo;
import java.net.UnknownHostException;
import org.springframework.web.client.RestTemplate;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.example.demo.Provider;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoException;
import org.json.JSONArray;
import org.json.JSONObject;

/*Code for Steps 1-4*/
@SpringBootApplication
public class RestClientNewApplication {

	public static void MongoInfo(  List<Provider> lstProvider )
	{
		 try {

				/**** Connect to MongoDB ****/
				// Since 2.10.0, uses MongoClient
				MongoClient mongo = new MongoClient("localhost", 27017);

				/**** Get database ****/
				// if database doesn't exists, MongoDB will create it for you
				DB db = mongo.getDB("YData");
				
				DBCollection table = db.getCollection("providersInfo");
				BasicDBObject document1 = new BasicDBObject();						
				table.remove(document1);
								
				
				
				int lrec = lstProvider.size();
				System.out.println("Mc:"+lrec);
				for (Provider prInf :  lstProvider)
			    {
				   String smid = prInf.getid();
				   String smName = prInf.getName();
				   String smBaseUrl = prInf.getbaseUrl();
				   String smCountryCode = prInf.getcountryISOCode();
				   BasicDBObject document = new BasicDBObject();
				   document.put("pid", smid);
					document.put("name", smName);
					document.put("baseUrl", smBaseUrl);
					document.put("countryISOCode", smCountryCode);
					table.insert(document);	   
					
			    }		

				
				/**** Done ****/
				System.out.println("Done");

			    } catch (UnknownHostException e) {
				e.printStackTrace();
			    } catch (MongoException e) {
				e.printStackTrace();
			    }

	}

	
	public static void main(String[] args) 
			//throws JsonParseException, JsonMappingException,	IOException
	{
		System.out.println("Start");
		RestTemplate obRestTemplate  = new RestTemplate();		
		String UrlVal = "https://developer.api.yodlee.com/ysl/providers";
		String autht="{cobSession=08062013_2:f64d4aa42841e23e6b4995ddbb8843d57cebc085a646c0a15f51f1937804dbb4ef81a90a3f7362029b44cc25391759a2c3b4b05162cce6cc3655cba9bcab33fd,userSession=08062013_2:81ad2e61473b40281ee86cc94ebcba4ba512c745ae6edd33c79c0fbeaaa7c6de7de189cf183391a4b2aebbe8e08cde266017c472d7c5c507954530016cdbc373}";
		
		try
		{
		HttpHeaders headers = new HttpHeaders();		
		headers.add("Cobrand-Name", "restserver");
		headers.add("Api-Version", "1.1");
		headers.add("Authorization", autht);
		headers.add("Accept", "application/json");			
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
				 
		ResponseEntity<String> result = 
		 obRestTemplate.exchange(UrlVal, HttpMethod.GET, entity, String.class);		
		String res = result.getBody();		
		System.out.println(res);	  
	    Providers prs = null;	    	    
	   JSONObject objectJson =  new JSONObject(res);
	    JSONArray objectJarr = objectJson.getJSONArray("provider");
	    System.out.println(objectJarr.length());	 
	    int noofRec = objectJarr.length();
	    List<Provider> lstProvider = new  ArrayList<Provider>();
	   for (int index=0; index<noofRec; ++index)
	    {
		   Provider prdetails = new Provider();
		   System.out.println("Record"+index);
	        JSONObject currentdata = objectJarr.getJSONObject(index);
	      String strId = currentdata.getString("id");
	        String strName = currentdata.getString("name");
	        String strbaseUrl = currentdata.getString("baseUrl");
	        String strcountryISOCode = currentdata.getString("countryISOCode");
	       // System.out.println(strId);
	       // System.out.println(strName);
	       // System.out.println(strbaseUrl);
	      //  System.out.println(strcountryISOCode);
	        
	        prdetails.setid(strId);
	        prdetails.setName(strName);
	        prdetails.setbaseUrl(strbaseUrl);
	        prdetails.setcountryISOCode(strcountryISOCode);
	        
	        lstProvider.add(prdetails);
	    }
	  // MongoInfo(lstProvider);
	   System.out.println(noofRec);
	   System.out.println("lst Rec"+lstProvider.size());
	  
		
		System.out.println("End");
		}		
        catch(Exception ex)
		{
        	ex.printStackTrace();
			
		}
		//}
		//SpringApplication.run(RestClientNewApplication.class, args);
	}
}
