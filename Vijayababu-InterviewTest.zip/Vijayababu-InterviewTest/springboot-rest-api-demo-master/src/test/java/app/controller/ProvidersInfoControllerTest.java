package app.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import app.Application;
import app.model.ProvidersInfo;
import app.repository.ProvidersInfoRepository;
import junit.framework.Assert;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebIntegrationTest
public class ProvidersInfoControllerTest {
	
	  public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();	
	  @Autowired
	  private ProvidersInfoRepository providersInfoRepository;	
	  private RestTemplate restTemplate = new TestRestTemplate();
	  

	  @Test
	  public void testCreateProvidersApi() throws JsonProcessingException{	    
	    //Building the Request body data
	    Map<String, Object> requestBody = new HashMap<String, Object>();	    
	    requestBody.put("pid", "1101");
	    requestBody.put("name", "testprovider1101");
	    requestBody.put("baseUrl", "www.google.com");
	    requestBody.put("countryISOCode", "US");
	    HttpHeaders requestHeaders = new HttpHeaders();
	    requestHeaders.setContentType(MediaType.APPLICATION_JSON);	   
	    HttpEntity<String> httpEntity =  new HttpEntity<String>(OBJECT_MAPPER.writeValueAsString(requestBody), requestHeaders);	    
	    String ServiceUrl = "http://localhost:8995/providersInfo";	    
	    Map<String, Object> apiResponse = restTemplate.postForObject(ServiceUrl, httpEntity, Map.class, Collections.EMPTY_MAP);
	    assertNotNull(apiResponse);	    
	    //Asserting the response of the API.
	    String message = apiResponse.get("message").toString();
	    assertEquals("Provider is added to DB", message);
	    String dbprId = ((Map<String, Object>)apiResponse.get("providersInfo")).get("id").toString();	    
	    assertNotNull(dbprId);  
	   
	  }
	  

	  @Test
	  public void testGetAllProvidersApi(){
	    //Add some test data for the API
		  ProvidersInfo prInfo = new ProvidersInfo("10001","testprovider10001","www.google.com","US");
		  providersInfoRepository.save(prInfo);
		  String ServiceUrl = "http://localhost:8995/providersInfo";	      
	   
	      Map<String, Object> apiResponse = restTemplate.getForObject(ServiceUrl, Map.class);
	    
	    //Assert the response from the API
	    int totalProviders = Integer.parseInt(apiResponse.get("totalproviders").toString());
	    assertTrue(totalProviders == 502);  // last count 501 before save
	    
	    List<Map<String, Object>> prvdsList = (List<Map<String, Object>>)apiResponse.get("providersInfo");
	    assertTrue(prvdsList.size() == 502);
	  }
	  
	  /*
	  @Test
		public void getProvidersbyName() {			
			 String prName = "MCI";				
			 List<ProvidersInfo> prs = providersInfoRepository.namequery(prName);			
			 int expectedCount = 1;
			 assertTrue(expectedCount == 1);
			
		}
	  
	  @Test
		public void getProvidersbyCountry() {			
			 String prCountry = "US";				
			 List<ProvidersInfo> prs = providersInfoRepository.countryquery(prCountry);			
			 int expectedCount = 100;
			 assertTrue(expectedCount == 100);
			
		}
	  */
	 

}
