package app.repository;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import app.model.ProvidersInfo;



public interface ProvidersInfoRepository extends MongoRepository<ProvidersInfo, String>
{
	

}


