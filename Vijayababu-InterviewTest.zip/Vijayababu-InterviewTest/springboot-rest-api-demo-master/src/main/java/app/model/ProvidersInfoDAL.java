package app.model;
import java.util.List;


import app.model.ProvidersInfo;

public interface ProvidersInfoDAL {			 
	
	List<ProvidersInfo> getAllProviders();	
	ProvidersInfo getProvidersInfoByName(String name); 
	ProvidersInfo addNewProvider(ProvidersInfo pr);	
	ProvidersInfo updateProvidersInfoByName(String name, String  countryISOCode);
	List<ProvidersInfo> getProviderCountriesCount(String country);
	List<ProvidersInfo> getProviderByName(String name);
	

}
